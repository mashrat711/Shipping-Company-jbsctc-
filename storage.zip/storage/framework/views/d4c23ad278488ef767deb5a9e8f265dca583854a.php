
<?php $__env->startSection('content'); ?>

		<!-- Page Title
		============================================= -->
		<section id="page-title" class="">

			<div class="container clearfix">
				<h1>Clients</h1>
				<span>A Short Page Title Tagline</span>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="#">Home</a></li>
					<li class="breadcrumb-item active" aria-current="page">Clients</li>
				</ol>
			</div>

		</section><!-- #page-title end -->

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				

					
					
					

						<!-- Posts
						============================================= -->


						<div class="container clearfix">

							<div class="col_one_third nobottommargin">
								<div class="feature-box media-box">
									<div class="fbox-media">
										<img src="<?php echo e(asset('assets/images/services/1.jpg')); ?>" alt="Why choose Us?">
									</div>
									<div class="fbox-desc">
										<h3>Why choose Us.<span class="subtitle">Because we are Reliable.</span></h3>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi rem, facilis nobis voluptatum est voluptatem accusamus molestiae eaque perspiciatis mollitia.</p>
									</div>
								</div>
							</div>

							<div class="col_one_third nobottommargin">
								<div class="feature-box media-box">
									<div class="fbox-media">
										<img src="<?php echo e(asset('assets/images/services/1.jpg')); ?>" alt="Why choose Us?">
									</div>
									<div class="fbox-desc">
										<h3>Our Mission.<span class="subtitle">To Redefine your Brand.</span></h3>
										<p>Quos, non, esse eligendi ab accusantium voluptatem. Maxime eligendi beatae, atque tempora ullam. Vitae delectus quia, consequuntur rerum molestias quo.</p>
									</div>
								</div>
							</div>

							<div class="col_one_third nobottommargin col_last">
								<div class="feature-box media-box">
									<div class="fbox-media">
										<img src="<?php echo e(asset('assets/images/services/1.jpg')); ?>" alt="Why choose Us?">
									</div>
									<div class="fbox-desc">
										<h3>What we Do.<span class="subtitle">Make our Customers Happy.</span></h3>
										<p>Porro repellat vero sapiente amet vitae quibusdam necessitatibus consectetur, labore totam. Accusamus perspiciatis asperiores labore esse ab accusantium ea modi ut.</p>
									</div>
								</div>
							</div>


						</div>
					<div class="content-wrap">
					<div class="container clearfix">

						<div class="col_one_third nobottommargin">
							<div class="feature-box media-box">
								<div class="fbox-media">
									<img src="<?php echo e(asset('assets/images/services/1.jpg')); ?>" alt="Why choose Us?">
								</div>
								<div class="fbox-desc">
									<h3>Why choose Us.<span class="subtitle">Because we are Reliable.</span></h3>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi rem, facilis nobis voluptatum est voluptatem accusamus molestiae eaque perspiciatis mollitia.</p>
								</div>
							</div>
						</div>

						<div class="col_one_third nobottommargin">
							<div class="feature-box media-box">
								<div class="fbox-media">
									<img src="<?php echo e(asset('assets/images/services/1.jpg')); ?>" alt="Why choose Us?">
								</div>
								<div class="fbox-desc">
									<h3>Our Mission.<span class="subtitle">To Redefine your Brand.</span></h3>
									<p>Quos, non, esse eligendi ab accusantium voluptatem. Maxime eligendi beatae, atque tempora ullam. Vitae delectus quia, consequuntur rerum molestias quo.</p>
								</div>
							</div>
						</div>

						
							
								
									
								
								
									
									
								
							
						


					</div>




							</div>



						</div>

					</div><!-- .sidebar end -->

				</div>

			</div>

		</section><!-- #content end -->

		<?php $__env->stopSection(); ?>
<?php echo $__env->make('demos.Frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Shipping\resources\views/demos/Frontend/clients.blade.php ENDPATH**/ ?>