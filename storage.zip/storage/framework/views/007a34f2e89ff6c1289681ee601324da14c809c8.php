
<?php $__env->startSection('content'); ?>

		<!-- Page Title
		============================================= -->
		<section id="page-title" class="nobg">

			<div class="container clearfix">
				<h1>About Us</h1>
				<span>A Short Page Title Tagline</span>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="#">Home</a></li>
					<li class="breadcrumb-item active" aria-current="page">About Us</li>
				</ol>
			</div>

		</section><!-- #page-title end -->

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="row clearfix">
						<div class="col-lg-6">
							<div class="heading-block nobottomborder bottommargin-sm">
								<h3>What We Do</h3>
								<span>Dramatically orchestrate multimedia based opportunities and client-based e-business. Competently create human capital.</span>
							</div>
							<p>Holisticly incubate enterprise users whereas just in time sources. Rapidiously transition performance based e-business for bricks-and-clicks methodologies. Intrinsicly network quality interfaces rather than customer directed e-services. Rapidiously implement out-of-the-box content with alternative data. Collaboratively simplify seamless initiatives through sustainable infomediaries. Holisticly aggregate bleeding-edge expertise.</p>
							<a href="#" class="button button-3d noleftmargin bottommargin-sm">Learn More</a>
						</div>

						<div class="col-lg-6">
							<div class="fslider flex-thumb-grid grid-6" data-pagi="false" data-arrows="false" data-thumbs="true">
								<div class="flexslider">
									<div class="slider-wrap">
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/1.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/1.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Government Contraction</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/2.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/2.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Home Renovation</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/3.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/3.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Residential Construction</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/4.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/4.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Wooden Floor</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/5.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/5.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Repairing of Houses</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/6.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/6.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Building Renovaion</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/7.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/7.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Hightech Construction</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/8.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/8.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Hardwood Flooring</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/9.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/9.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Commercial Construction</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/10.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/10.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Repairing Of Roof</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/11.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/11.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Home Renovation</div>
										</div>
										<div class="slide" data-thumb="<?php echo e(asset('assets/images/gallery/thumbs/12.jpg')); ?>">
											<img src="<?php echo e(asset('assets/images/gallery/12.jpg')); ?>" alt="Image">
											<div class="flex-caption slider-caption-bg slider-caption-bg-light">Office Renovation</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="clear"></div>


				</div>

			</div>

		</section><!-- #content end -->

		<?php $__env->stopSection(); ?>
<?php echo $__env->make('demos.Frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Shipping\resources\views/demos/Frontend/home.blade.php ENDPATH**/ ?>